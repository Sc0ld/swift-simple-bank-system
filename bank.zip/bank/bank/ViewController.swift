//
//  ViewController.swift
//  bank
//
//  Created by Eyad on 25/02/1444 AH.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestore
class ViewController: UIViewController {

    @IBOutlet weak var emailtxt: UITextField!
    @IBOutlet weak var passtxt: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        FirebaseApp.configure()
    }

    @IBAction func logbtn(_ sender: Any) {
        Auth.auth().signIn(withEmail: emailtxt.text! , password: passtxt.text!) {(usr,err) in
            if usr != nil {
                let userID = Auth.auth().currentUser!.uid
                let a = self.storyboard?.instantiateViewController(withIdentifier: "mainview") as! ViewController4
                a.usrid = userID
                a.modalPresentationStyle = .fullScreen
                self.present(a, animated:true, completion:nil)
            } else {
                print("Wrong Email OR Password")
            }
        }
    }
}
class ViewController2: UIViewController {
    
    @IBOutlet weak var emailtxt: UITextField!
    @IBOutlet weak var usernametxt: UITextField!
    @IBOutlet weak var passtxt: UITextField!
    @IBOutlet weak var copasstxt: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func regbtn(_ sender: Any) {
        if passtxt.text == copasstxt.text {
        Auth.auth().createUser(withEmail: emailtxt.text!, password: passtxt.text!) {(usr,err) in
            if usr != nil {
            let userID = Auth.auth().currentUser!.uid
                Firestore.firestore().collection("users").document(userID).setData(["username" : self.usernametxt.text!,"email": self.emailtxt.text!,"userid" : userID,"Cash" : 0])
            }
        }
        } else {
            print("password is not the same")
        }
    }
}
class ViewController3: UIViewController {
    @IBOutlet weak var emailttxt: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func sendbtn(_ sender: Any) {
        Auth.auth().sendPasswordReset(withEmail: emailttxt.text!)
        }
    }

class ViewController4: UIViewController {
    var usrid : String?
    @IBOutlet weak var userlabel: UILabel!
    @IBOutlet weak var email: UILabel!
    @IBOutlet weak var cash: UILabel!
    @IBOutlet weak var walletid: UILabel!
    @IBOutlet weak var sendwalletid: UITextField!
    @IBOutlet weak var cashsend: UITextField!
    var username : String?;
    var emaild : String?;
    var cashd : Int?;
    var cashd2 : Int?;
    override func viewDidLoad() {
        super.viewDidLoad()
     getdata()
    }
    func getdata () {
        Firestore.firestore().collection("users").document(usrid!).getDocument(completion: { [self] querySnapshot, error in
            guard let snapshot = querySnapshot else {
                print("Error fetching snapshots: \(error!)")
                return
            }
            self.username = snapshot.data()?["username"] as! String
            self.emaild =  snapshot.data()?["email"] as! String
            self.cashd = snapshot.data()?["Cash"]  as! Int
            self.walletid.text = "wallet address : " + self.usrid!
            self.userlabel.text! = "username : " + username!
            self.email.text! = "email : " + emaild!
            self.cash.text! = "cash : " + cashd!.description
        })
    }
    
    @IBAction func sendbtn(_ sender: Any) {
        if walletid.text == sendwalletid.text {
            print("You can't tr money to your self")
        } else {
        print(cashd)
        let a:Int? = Int(cashsend.text!)
        if a! > cashd! {
            print("You don't have money")
        } else {
            Firestore.firestore().collection("users").document(sendwalletid.text!).getDocument(completion: { [self] querySnapshot, error in
                guard let snapshot = querySnapshot else {
                    print("Error fetching snapshots: \(error!)")
                    return
                }
                self.cashd2 = snapshot.data()?["Cash"]  as! Int
                let sendemail = snapshot.data()?["email"]  as! String
                let sendusername = snapshot.data()?["username"]  as! String
                print(cashd2)
                let newcashsend = cashd2! + a!;
                print(newcashsend)
                Firestore.firestore().collection("users").document(sendwalletid.text!).setData(["username" : sendusername,"email": sendemail,"userid" : sendwalletid.text!,"Cash" : newcashsend])
                let newcash = cashd! - a!;
                Firestore.firestore().collection("users").document(usrid!).setData(["username" : self.username!,"email": self.emaild!,"userid" : usrid!,"Cash" : newcash])
               print(newcash)
                getnewdata()
            })
        }
        }
        func getnewdata() {
            Firestore.firestore().collection("users").document(usrid!).getDocument(completion: { [self] querySnapshot, error in
                guard let snapshot = querySnapshot else {
                    print("Error fetching snapshots: \(error!)")
                    return
                }
                self.cashd = snapshot.data()?["Cash"]  as! Int
                self.cash.text! = "cash : " + cashd!.description
            })
        }
    }
}
